import axios from "axios";

const API =
  "/api/users";

const getConfig = () => ({
  headers: {
    Authorization: `Bearer ${localStorage.getItem(
      "token"
    )}`,
  },
});

export const updateProfile = (data) =>
  axios.put(
    `${API}/update`,
    data,
    getConfig()
  );

export const getCurrentUser = () =>
  axios.get(
    `${API}/me`,
    getConfig()
  );


export const uploadAvatar = (avatarFile) => {
  const formData = new FormData();

  formData.append("avatar", avatarFile);

  return axios.post(`${API}/avatar`, formData, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });
};
