# Run locally with Docker Compose

This repository can run the React frontend, Express API, and Python AI service together using Docker.

## Prerequisites

- Docker Desktop installed and running (Windows/macOS), or Docker Engine + Docker Compose (Linux).
- A MongoDB Atlas database and its connection string.
- A Cloudinary account and API credentials.

You do **not** need to install Node.js, Python, PyTorch, SentenceTransformers, or Tesseract on the host computer. Docker builds those into the containers.

## First-time setup

1. Download and extract this repository.
2. In the extracted project root (the folder containing `docker-compose.yml`), create your environment file:

   **PowerShell**
   ```powershell
   Copy-Item .env.example .env
   ```

   **macOS/Linux**
   ```bash
   cp .env.example .env
   ```

3. Open `.env` and enter your own `MONGO_URI`, `JWT_SECRET`, and Cloudinary credentials. Do not share this file or commit it to GitHub.
4. In MongoDB Atlas, allow network access from the computer running Docker. For a quick local test, Atlas may require adding the current public IP address in Network Access. Avoid leaving broad access enabled longer than necessary.
5. Make sure Docker Desktop is running.
6. From the project root, build and start everything:

   ```bash
   docker compose up --build
   ```

7. Open **http://localhost:5173**.

The first build can take several minutes. The AI container downloads the SentenceTransformer and CLIP model weights on first startup. An internet connection and several GB of free disk space are needed. The AI models also need substantial RAM; a computer with 8 GB system RAM or more is recommended, and Docker Desktop must be allowed enough memory.

## Useful commands

Start after the first build:
```bash
docker compose up
```

Run in the background:
```bash
docker compose up -d
```

View logs:
```bash
docker compose logs -f
```

View only AI service logs:
```bash
docker compose logs -f ai-service
```

Stop containers (keeps the downloaded model cache):
```bash
docker compose down
```

Stop and remove the downloaded model cache:
```bash
docker compose down -v
```

Rebuild after changing source or dependencies:
```bash
docker compose up --build
```

## Service addresses

- Website: http://localhost:5173
- Express API (proxied through the frontend): http://localhost:5173/api
- AI service is internal to the Docker network at `http://ai-service:8000`; the browser does not need direct access to it.

## Troubleshooting

- **MongoDB connection error:** verify `MONGO_URI`, the Atlas database user/password, and Atlas Network Access.
- **Cloudinary upload error:** verify all three Cloudinary values in `.env`.
- **AI service still loading:** wait for the first model download; inspect `docker compose logs -f ai-service`.
- **Out of memory:** increase Docker Desktop memory in Settings → Resources, close other memory-heavy applications, or use a machine with more RAM. Do not assume the AI service will fit in a 512 MB environment.
- **Port 5173 already in use:** change `FRONTEND_PORT` in `.env` (for example, `FRONTEND_PORT=5174`) and open the matching localhost port.
- **Port 5000 already in use:** stop the other application using it before starting this stack.

## Notes

- MongoDB Atlas and Cloudinary remain external services; Docker does not create those accounts or supply credentials.
- Uploaded item/avatar images are sent to Cloudinary. The server's `uploads/` directory is used for temporary upload files.
- The first run requires internet access to download Docker base images, Python/Node dependencies, and AI model files.
- Keep your real `.env` private. Only `.env.example` belongs in GitHub.

---

# FindBack - AI-Based Lost & Found Portal

> A full-stack campus Lost & Found platform that uses AI-powered semantic matching to connect lost-item reports with relevant found-item reports.

![React](https://img.shields.io/badge/Frontend-React-61DAFB?logo=react&logoColor=black)
![Node.js](https://img.shields.io/badge/Backend-Node.js-339933?logo=node.js&logoColor=white)
![Express](https://img.shields.io/badge/API-Express-000000?logo=express&logoColor=white)
![MongoDB](https://img.shields.io/badge/Database-MongoDB-47A248?logo=mongodb&logoColor=white)
![Python](https://img.shields.io/badge/AI-Python-3776AB?logo=python&logoColor=white)
![FastAPI](https://img.shields.io/badge/AI%20API-FastAPI-009688?logo=fastapi&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/UI-Tailwind%20CSS-06B6D4?logo=tailwindcss&logoColor=white)

---

## Overview

FindBack is a full-stack web application designed to digitize the lost-and-found process on a college campus.

Users can create reports for lost or found belongings, upload item images, browse community reports, search and filter listings, manage their own reports, and view detailed item information.

The key feature is an AI-powered semantic matching system. Instead of relying only on exact keyword matches, the system converts item descriptions into vector embeddings using the `all-MiniLM-L6-v2` Sentence Transformer model and compares lost reports against found reports using cosine similarity.

This allows semantically similar descriptions to be identified even when the wording is different.

---

## Key Features

### Authentication

- User registration and login
- JWT-based authentication
- Password hashing with bcrypt
- Protected API routes
- User-specific item management
- Role support for users and administrators

### Lost & Found Management

- Create lost and found reports
- Add title, description, category, location and date
- Upload item images
- View detailed item information
- Edit owned reports
- Delete owned reports
- View personal reports through My Items

### Search & Filtering

- Search by title, description, category and location
- Filter by Lost / Found status
- Filter by category
- Filter by date range
- Combine multiple filters
- Dynamic result count

### AI Semantic Matching

- Sentence Transformer based semantic matching
- `all-MiniLM-L6-v2` embedding model
- Cosine similarity calculation
- Opposite-status candidate matching
- Similarity-based ranking
- Strong matches surfaced to users
- AI match results displayed on item details pages

### Image Management

- Item image uploads
- User avatar uploads
- Cloudinary integration
- Image previews
- Responsive image display

---

## AI Semantic Matching

The AI matching system is implemented as a separate Python FastAPI microservice.

```text
                    +----------------------+
                    |    React Frontend    |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Node.js + Express  |
                    |       REST API       |
                    +------+-----------+---+
                           |           |
                           |           v
                           |   +------------------+
                           |   |  Python FastAPI  |
                           |   |    AI Service    |
                           |   +--------+---------+
                           |            |
                           |            v
                           |   +------------------+
                           |   | all-MiniLM-L6-v2 |
                           |   | Sentence         |
                           |   | Transformer      |
                           |   +--------+---------+
                           |            |
                           |            v
                           |   +------------------+
                           |   | Cosine Similarity|
                           |   | + Ranking        |
                           |   +------------------+
                           |
                           v
                    +----------------------+
                    |       MongoDB        |
                    +----------------------+


